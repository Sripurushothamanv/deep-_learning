import subprocess,sys
for i in range(1,31):
 folder=f'Experiment_{i:02d}'
 print('Running',folder,flush=True)
 subprocess.run([sys.executable,'main.py'],cwd=folder,check=True)
