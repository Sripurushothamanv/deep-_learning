# Deep Learning Lab Experiments (CO1–CO5)

Includes runnable Python implementations for Experiments 1–29 and the additional generative-model evaluation experiment. Each experiment folder contains `main.py`, `output.txt`, `output_screenshot.png`, generated plots (when relevant), and a README.

**Note:** To keep the repository runnable on ordinary laptops without large datasets or GPU requirements, several deep-learning experiments use small synthetic datasets and simplified NumPy/Scikit-learn simulations where the assignment permits. The original questions are preserved in `ORIGINAL_ASSIGNMENT.txt`.

Run an experiment:
```bash
python Experiment_01/main.py
```
Run all:
```bash
python run_all.py
```
